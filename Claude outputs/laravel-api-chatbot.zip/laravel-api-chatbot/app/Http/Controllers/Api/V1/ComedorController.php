<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\EventoComedorResource;
use App\Models\EventoComedor;
use App\Models\RegistroComedor;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Support\Facades\DB;

class ComedorController extends Controller
{
    /**
     * GET /api/v1/comedor/eventos
     *
     * Público. Próximos eventos activos del comedor solidario,
     * con el cupo que queda disponible en cada uno.
     */
    public function index(): AnonymousResourceCollection
    {
        $eventos = EventoComedor::query()
            ->where('activo', true)
            ->whereDate('fecha', '>=', now()->toDateString())
            ->withSum(
                ['registros as personas_registradas' => fn ($q) => $q->where('estatus', '!=', 'cancelado')],
                'numero_personas'
            )
            ->orderBy('fecha')
            ->orderBy('hora_inicio')
            ->get();

        return EventoComedorResource::collection($eventos);
    }

    /**
     * GET /api/v1/comedor/registros
     *
     * Requiere token. Personas inscritas a los eventos del comedor.
     *
     * Filtros opcionales:
     *   ?evento_id=3
     *   ?estatus=pendiente
     */
    public function registros(Request $request): \Illuminate\Http\JsonResponse
    {
        $request->validate([
            'evento_id'  => ['nullable', 'integer', 'exists:eventos_comedor,id'],
            'estatus'    => ['nullable', 'string', 'max:30'],
            'por_pagina' => ['nullable', 'integer', 'min:1', 'max:100'],
        ]);

        $registros = RegistroComedor::query()
            ->when($request->filled('evento_id'), fn ($q) => $q->where('evento_id', $request->integer('evento_id')))
            ->when($request->filled('estatus'), fn ($q) => $q->where('estatus', $request->string('estatus')))
            ->orderByDesc('created_at')
            ->paginate($request->integer('por_pagina', 20));

        return response()->json([
            'ok'    => true,
            'datos' => $registros->through(fn ($r) => [
                'folio'            => 'COMEDOR-' . str_pad((string) $r->id, 6, '0', STR_PAD_LEFT),
                'evento_id'        => $r->evento_id,
                'nombre_completo'  => trim("{$r->nombre} {$r->apellido_paterno} {$r->apellido_materno}"),
                'celular'          => $r->celular_1,
                'correo'           => $r->correo,
                'municipio'        => $r->municipio,
                'colonia'          => $r->colonia,
                'numero_personas'  => (int) $r->numero_personas,
                'observaciones'    => $r->observaciones,
                'estatus'          => $r->estatus,
                'registrado_en'    => optional($r->created_at)->toIso8601String(),
            ]),
        ]);
    }
}

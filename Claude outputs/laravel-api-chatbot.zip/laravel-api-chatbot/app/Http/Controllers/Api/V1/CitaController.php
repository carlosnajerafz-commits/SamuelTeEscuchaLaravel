<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\CitaResource;
use App\Models\Cita;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class CitaController extends Controller
{
    /** Horarios de atención del martes ciudadano. */
    private const HORARIOS = [
        '09:00', '09:20', '09:40', '10:00', '10:20', '10:40',
        '11:00', '11:20', '11:40', '12:00', '12:20', '12:40',
        '13:00', '13:20', '13:40', '14:00', '14:20', '14:40',
    ];

    private const ESTATUS_VALIDOS = [
        'solicitada', 'aceptada', 'realizada', 'cancelada', 'vencida', 'rechazada',
    ];

    /**
     * GET /api/v1/citas
     *
     * Listado paginado de citas. Requiere token.
     *
     * Filtros opcionales:
     *   ?estatus=solicitada
     *   ?desde=2026-01-01&hasta=2026-12-31
     *   ?por_pagina=25
     */
    public function index(Request $request): AnonymousResourceCollection
    {
        $request->validate([
            'estatus'    => ['nullable', 'string', 'in:' . implode(',', self::ESTATUS_VALIDOS)],
            'desde'      => ['nullable', 'date_format:Y-m-d'],
            'hasta'      => ['nullable', 'date_format:Y-m-d', 'after_or_equal:desde'],
            'por_pagina' => ['nullable', 'integer', 'min:1', 'max:100'],
        ]);

        $citas = Cita::query()
            ->when($request->filled('estatus'), fn ($q) => $q->where('estatus', $request->string('estatus')))
            ->when($request->filled('desde'), fn ($q) => $q->whereDate('fecha', '>=', $request->date('desde')))
            ->when($request->filled('hasta'), fn ($q) => $q->whereDate('fecha', '<=', $request->date('hasta')))
            ->orderBy('fecha', 'desc')
            ->orderBy('hora', 'desc')
            ->paginate($request->integer('por_pagina', 20));

        return CitaResource::collection($citas);
    }

    /**
     * GET /api/v1/citas/{id}
     */
    public function show(Cita $cita): CitaResource
    {
        return new CitaResource($cita);
    }

    /**
     * PATCH /api/v1/citas/{id}/estatus
     *
     * Cuerpo: { "estatus": "aceptada" }
     */
    public function actualizarEstatus(Request $request, Cita $cita): JsonResponse
    {
        $datos = $request->validate([
            'estatus' => ['required', 'string', 'in:' . implode(',', self::ESTATUS_VALIDOS)],
        ]);

        $anterior = $cita->estatus;
        $cita->estatus = $datos['estatus'];
        $cita->save();

        return response()->json([
            'ok'      => true,
            'mensaje' => 'Estatus actualizado correctamente.',
            'datos'   => [
                'folio'            => $this->folio($cita->id),
                'estatus_anterior' => $anterior,
                'estatus_actual'   => $cita->estatus,
                'actualizado_por'  => $request->user()->usuario,
            ],
        ]);
    }

    /**
     * GET /api/v1/citas/disponibilidad/{fecha}
     *
     * Público. Devuelve los horarios libres de un martes concreto,
     * sin exponer quién tiene ocupados los demás.
     */
    public function disponibilidad(string $fecha): JsonResponse
    {
        $dia = Carbon::createFromFormat('Y-m-d', $fecha)->startOfDay();

        if (! $dia->isTuesday()) {
            return response()->json([
                'ok'      => false,
                'mensaje' => 'Las citas únicamente se agendan los martes.',
            ], 422);
        }

        if ($dia->isPast()) {
            return response()->json([
                'ok'      => false,
                'mensaje' => 'No es posible agendar en una fecha que ya pasó.',
            ], 422);
        }

        $ocupados = Cita::whereDate('fecha', $dia)
            ->whereIn('estatus', ['solicitada', 'aceptada'])
            ->pluck('hora')
            ->map(fn ($h) => substr((string) $h, 0, 5))
            ->all();

        $libres = array_values(array_diff(self::HORARIOS, $ocupados));

        return response()->json([
            'ok'    => true,
            'datos' => [
                'fecha'            => $dia->toDateString(),
                'horarios_libres'  => $libres,
                'total_libres'     => count($libres),
                'total_horarios'   => count(self::HORARIOS),
            ],
        ]);
    }

    private function folio(int $id): string
    {
        return 'CITA-' . str_pad((string) $id, 6, '0', STR_PAD_LEFT);
    }
}

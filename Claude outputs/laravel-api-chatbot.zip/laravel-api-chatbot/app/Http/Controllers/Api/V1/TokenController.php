<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Empleado;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

/**
 * Emisión y revocación de tokens de acceso a la API.
 *
 * El token se entrega a un empleado autenticado y se usa después
 * en la cabecera: Authorization: Bearer <token>
 */
class TokenController extends Controller
{
    /**
     * POST /api/v1/token
     *
     * Valida las credenciales del empleado y emite un token Sanctum.
     */
    public function store(Request $request): JsonResponse
    {
        $datos = $request->validate([
            'usuario'    => ['required', 'string', 'max:100'],
            'password'   => ['required', 'string'],
            'dispositivo' => ['nullable', 'string', 'max:100'],
        ]);

        $empleado = Empleado::where('usuario', $datos['usuario'])->first();

        // Mensaje genérico: no revelamos si el usuario existe o no.
        if (! $empleado || ! Hash::check($datos['password'], $empleado->password)) {
            throw ValidationException::withMessages([
                'usuario' => ['Las credenciales proporcionadas son incorrectas.'],
            ]);
        }

        $nombreDispositivo = $datos['dispositivo'] ?? 'api-cliente';
        $token = $empleado->createToken($nombreDispositivo);

        return response()->json([
            'ok'    => true,
            'datos' => [
                'token'     => $token->plainTextToken,
                'tipo'      => 'Bearer',
                'empleado'  => [
                    'id'      => $empleado->id,
                    'usuario' => $empleado->usuario,
                    'nombre'  => $empleado->nombre,
                ],
            ],
        ], 201);
    }

    /**
     * GET /api/v1/me
     *
     * Devuelve el empleado dueño del token en uso.
     */
    public function me(Request $request): JsonResponse
    {
        $empleado = $request->user();

        return response()->json([
            'ok'    => true,
            'datos' => [
                'id'      => $empleado->id,
                'usuario' => $empleado->usuario,
                'nombre'  => $empleado->nombre,
            ],
        ]);
    }

    /**
     * DELETE /api/v1/token
     *
     * Revoca el token con el que se hizo la petición (cerrar sesión).
     */
    public function destroy(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'ok'      => true,
            'mensaje' => 'Token revocado correctamente.',
        ]);
    }
}

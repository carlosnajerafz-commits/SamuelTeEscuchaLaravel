<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Cita;
use App\Models\Queja;
use App\Models\RegistroApoyo;
use App\Models\RegistroComedor;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Consulta de seguimiento para el ciudadano.
 *
 * NOTA DE SEGURIDAD
 * -----------------
 * Los folios son correlativos (CITA-000014 es el registro 14), de modo que
 * cualquiera podría recorrerlos uno por uno. Por eso este endpoint:
 *
 *   1. Exige folio Y el celular con el que se hizo la solicitud.
 *   2. Devuelve únicamente el estatus y la fecha de registro: nunca
 *      nombre, domicilio, correo ni el contenido de la solicitud.
 *   3. Responde exactamente igual cuando el folio no existe y cuando
 *      el celular no coincide, para no revelar qué folios están en uso.
 *   4. Está limitado a 10 consultas por minuto por IP (ver routes/api.php).
 */
class SeguimientoController extends Controller
{
    /** Prefijo de folio => [modelo, etiqueta legible] */
    private const TIPOS = [
        'CITA'    => [Cita::class,            'Cita ciudadana'],
        'QUEJA'   => [Queja::class,           'Queja o reporte'],
        'APOYO'   => [RegistroApoyo::class,   'Solicitud de apoyo'],
        'COMEDOR' => [RegistroComedor::class, 'Comedor solidario'],
    ];

    /**
     * POST /api/v1/seguimiento
     *
     * Cuerpo: { "folio": "CITA-000014", "celular": "5512345678" }
     */
    public function consultar(Request $request): JsonResponse
    {
        $datos = $request->validate([
            'folio'   => ['required', 'string', 'regex:/^(CITA|QUEJA|APOYO|COMEDOR)-\d{1,6}$/i'],
            'celular' => ['required', 'string', 'regex:/^\d{10}$/'],
        ], [
            'folio.regex'   => 'El folio debe tener el formato CITA-000001, QUEJA-000001, APOYO-000001 o COMEDOR-000001.',
            'celular.regex' => 'El celular debe tener exactamente 10 dígitos.',
        ]);

        [$prefijo, $id] = $this->partirFolio($datos['folio']);

        $registro = $this->buscar($prefijo, $id, $datos['celular']);

        // Misma respuesta para folio inexistente y celular que no coincide.
        if (! $registro) {
            return response()->json([
                'ok'      => false,
                'mensaje' => 'No encontramos una solicitud con ese folio y ese número de celular. '
                           . 'Verifica ambos datos o comunícate al 55 2172 4723.',
            ], 404);
        }

        return response()->json([
            'ok'    => true,
            'datos' => [
                'folio'         => strtoupper($prefijo) . '-' . str_pad((string) $id, 6, '0', STR_PAD_LEFT),
                'tipo'          => self::TIPOS[$prefijo][1],
                'estatus'       => $registro->estatus,
                'descripcion'   => $this->describirEstatus($prefijo, (string) $registro->estatus),
                'registrado_en' => optional($registro->created_at)->toDateString(),
            ],
        ]);
    }

    /**
     * Separa "CITA-000014" en ['CITA', 14].
     *
     * @return array{0: string, 1: int}
     */
    private function partirFolio(string $folio): array
    {
        [$prefijo, $numero] = explode('-', strtoupper(trim($folio)), 2);

        return [$prefijo, (int) ltrim($numero, '0')];
    }

    /**
     * Busca el registro exigiendo que el celular coincida.
     */
    private function buscar(string $prefijo, int $id, string $celular): ?Model
    {
        if ($id < 1 || ! isset(self::TIPOS[$prefijo])) {
            return null;
        }

        /** @var class-string<Model> $modelo */
        $modelo = self::TIPOS[$prefijo][0];

        return $modelo::query()
            ->where('id', $id)
            ->where(function ($q) use ($celular) {
                $q->where('celular_1', $celular)
                  ->orWhere('celular_2', $celular);
            })
            ->first();
    }

    /**
     * Explica el estatus en lenguaje entendible para el ciudadano.
     */
    private function describirEstatus(string $prefijo, string $estatus): string
    {
        $mapa = [
            'CITA' => [
                'solicitada' => 'Tu solicitud está en revisión. Te contactaremos para confirmarla.',
                'aceptada'   => 'Tu cita fue confirmada. Te esperamos en la fecha y hora acordadas.',
                'realizada'  => 'La cita ya se llevó a cabo.',
                'cancelada'  => 'La cita fue cancelada.',
                'rechazada'  => 'La solicitud no pudo ser aceptada. Comunícate con la oficina para más información.',
                'vencida'    => 'La fecha de la cita ya pasó y no se registró asistencia.',
            ],
            'QUEJA' => [
                'pendiente'  => 'Tu reporte fue recibido y está en espera de revisión.',
                'atendida'   => 'Tu reporte fue canalizado a la dependencia correspondiente.',
                'completada' => 'El reporte fue resuelto.',
                'cerrada'    => 'El reporte fue cerrado.',
            ],
            'APOYO' => [
                'pendiente'  => 'Tu solicitud fue recibida y está en revisión.',
                'en proceso' => 'Tu solicitud está siendo gestionada.',
                'entregado'  => 'El apoyo fue entregado.',
                'cancelado'  => 'La solicitud fue cancelada.',
            ],
            'COMEDOR' => [
                'pendiente'  => 'Tu registro fue recibido. Preséntate el día del evento.',
                'confirmado' => 'Tu lugar está confirmado.',
                'asistio'    => 'Se registró tu asistencia.',
                'cancelado'  => 'El registro fue cancelado.',
            ],
        ];

        return $mapa[$prefijo][$estatus]
            ?? 'Consulta el detalle comunicándote al 55 2172 4723.';
    }
}

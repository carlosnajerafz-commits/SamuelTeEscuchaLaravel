<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\ApoyoResource;
use App\Http\Resources\RegistroApoyoResource;
use App\Models\Apoyo;
use App\Models\RegistroApoyo;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class ApoyoController extends Controller
{
    private const ESTATUS_VALIDOS = ['pendiente', 'en proceso', 'entregado', 'cancelado'];

    /**
     * GET /api/v1/apoyos
     *
     * Público. Catálogo de apoyos activos. No contiene datos personales.
     */
    public function index(): AnonymousResourceCollection
    {
        $apoyos = Apoyo::where('activo', true)
            ->orderByDesc('created_at')
            ->get();

        return ApoyoResource::collection($apoyos);
    }

    /**
     * GET /api/v1/registros-apoyo
     *
     * Requiere token. Solicitudes de apoyo presentadas por ciudadanos.
     *
     * Filtros opcionales:
     *   ?estatus=pendiente
     *   ?apoyo=Despensa
     *   ?por_pagina=25
     */
    public function registros(Request $request): AnonymousResourceCollection
    {
        $request->validate([
            'estatus'    => ['nullable', 'string', 'in:' . implode(',', self::ESTATUS_VALIDOS)],
            'apoyo'      => ['nullable', 'string', 'max:150'],
            'por_pagina' => ['nullable', 'integer', 'min:1', 'max:100'],
        ]);

        $registros = RegistroApoyo::query()
            ->when($request->filled('estatus'), fn ($q) => $q->where('estatus', $request->string('estatus')))
            ->when($request->filled('apoyo'), fn ($q) => $q->where('apoyo', $request->string('apoyo')))
            ->orderByDesc('created_at')
            ->paginate($request->integer('por_pagina', 20));

        return RegistroApoyoResource::collection($registros);
    }

    /**
     * PATCH /api/v1/registros-apoyo/{id}/estatus
     */
    public function actualizarEstatus(Request $request, RegistroApoyo $registro): JsonResponse
    {
        $datos = $request->validate([
            'estatus' => ['required', 'string', 'in:' . implode(',', self::ESTATUS_VALIDOS)],
        ]);

        $anterior = $registro->estatus;
        $registro->estatus = $datos['estatus'];
        $registro->save();

        return response()->json([
            'ok'      => true,
            'mensaje' => 'Estatus actualizado correctamente.',
            'datos'   => [
                'folio'            => 'APOYO-' . str_pad((string) $registro->id, 6, '0', STR_PAD_LEFT),
                'estatus_anterior' => $anterior,
                'estatus_actual'   => $registro->estatus,
                'actualizado_por'  => $request->user()->usuario,
            ],
        ]);
    }
}

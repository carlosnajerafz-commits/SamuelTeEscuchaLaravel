<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\QuejaResource;
use App\Models\Queja;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class QuejaController extends Controller
{
    private const ESTATUS_VALIDOS = ['pendiente', 'atendida', 'completada', 'cerrada'];

    /**
     * GET /api/v1/quejas
     *
     * Filtros opcionales:
     *   ?estatus=pendiente
     *   ?tipo=Alumbrado
     *   ?municipio=Tecámac
     *   ?por_pagina=25
     */
    public function index(Request $request): AnonymousResourceCollection
    {
        $request->validate([
            'estatus'    => ['nullable', 'string', 'in:' . implode(',', self::ESTATUS_VALIDOS)],
            'tipo'       => ['nullable', 'string', 'max:60'],
            'municipio'  => ['nullable', 'string', 'max:100'],
            'por_pagina' => ['nullable', 'integer', 'min:1', 'max:100'],
        ]);

        $quejas = Queja::query()
            ->when($request->filled('estatus'), fn ($q) => $q->where('estatus', $request->string('estatus')))
            ->when($request->filled('tipo'), fn ($q) => $q->where('tipo', $request->string('tipo')))
            ->when($request->filled('municipio'), fn ($q) => $q->where('municipio', $request->string('municipio')))
            ->orderByDesc('created_at')
            ->paginate($request->integer('por_pagina', 20));

        return QuejaResource::collection($quejas);
    }

    /**
     * GET /api/v1/quejas/{id}
     */
    public function show(Queja $queja): QuejaResource
    {
        return new QuejaResource($queja);
    }

    /**
     * PATCH /api/v1/quejas/{id}/estatus
     */
    public function actualizarEstatus(Request $request, Queja $queja): JsonResponse
    {
        $datos = $request->validate([
            'estatus' => ['required', 'string', 'in:' . implode(',', self::ESTATUS_VALIDOS)],
        ]);

        $anterior = $queja->estatus;
        $queja->estatus = $datos['estatus'];
        $queja->save();

        return response()->json([
            'ok'      => true,
            'mensaje' => 'Estatus actualizado correctamente.',
            'datos'   => [
                'folio'            => 'QUEJA-' . str_pad((string) $queja->id, 6, '0', STR_PAD_LEFT),
                'estatus_anterior' => $anterior,
                'estatus_actual'   => $queja->estatus,
                'actualizado_por'  => $request->user()->usuario,
            ],
        ]);
    }
}

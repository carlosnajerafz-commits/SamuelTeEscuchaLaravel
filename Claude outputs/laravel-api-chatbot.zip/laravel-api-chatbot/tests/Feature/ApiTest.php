<?php

namespace Tests\Feature;

use App\Models\Apoyo;
use App\Models\Cita;
use App\Models\Empleado;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

/**
 * Pruebas de la API v1.
 *
 * Cubren control de acceso, validación de datos y, sobre todo, que el
 * endpoint de seguimiento no filtre información a quien no debe verla.
 *
 * Ejecutar con:  php artisan test --filter=ApiTest
 */
class ApiTest extends TestCase
{
    use RefreshDatabase;

    /* ==========================================================
       CONTROL DE ACCESO
    ========================================================== */

    public function test_las_rutas_protegidas_rechazan_peticiones_sin_token(): void
    {
        $this->getJson('/api/v1/citas')->assertUnauthorized();
        $this->getJson('/api/v1/quejas')->assertUnauthorized();
        $this->getJson('/api/v1/estadisticas')->assertUnauthorized();
    }

    public function test_un_empleado_autenticado_si_puede_listar_citas(): void
    {
        Sanctum::actingAs(Empleado::factory()->create());

        $this->getJson('/api/v1/citas')->assertOk();
    }

    public function test_el_token_se_emite_con_credenciales_validas(): void
    {
        Empleado::factory()->create([
            'usuario'  => 'prueba',
            'password' => Hash::make('ClaveSegura123'),
        ]);

        $this->postJson('/api/v1/token', [
            'usuario'  => 'prueba',
            'password' => 'ClaveSegura123',
        ])
            ->assertCreated()
            ->assertJsonStructure(['ok', 'datos' => ['token', 'tipo', 'empleado']]);
    }

    public function test_el_token_se_niega_con_contrasena_incorrecta(): void
    {
        Empleado::factory()->create([
            'usuario'  => 'prueba',
            'password' => Hash::make('ClaveSegura123'),
        ]);

        $this->postJson('/api/v1/token', [
            'usuario'  => 'prueba',
            'password' => 'claveEquivocada',
        ])->assertStatus(422);
    }

    /* ==========================================================
       ENDPOINTS PÚBLICOS
    ========================================================== */

    public function test_el_catalogo_de_apoyos_es_publico_y_solo_muestra_activos(): void
    {
        Apoyo::factory()->create(['nombre' => 'Despensa', 'activo' => true]);
        Apoyo::factory()->create(['nombre' => 'Programa cerrado', 'activo' => false]);

        $this->getJson('/api/v1/apoyos')
            ->assertOk()
            ->assertJsonFragment(['nombre' => 'Despensa'])
            ->assertJsonMissing(['nombre' => 'Programa cerrado']);
    }

    public function test_la_disponibilidad_rechaza_un_dia_que_no_es_martes(): void
    {
        $miercoles = now()->next(\Carbon\Carbon::WEDNESDAY)->toDateString();

        $this->getJson("/api/v1/citas/disponibilidad/{$miercoles}")
            ->assertStatus(422)
            ->assertJson(['ok' => false]);
    }

    /* ==========================================================
       SEGUIMIENTO: lo más sensible
    ========================================================== */

    public function test_el_seguimiento_devuelve_el_estatus_con_folio_y_celular_correctos(): void
    {
        $cita = Cita::factory()->create([
            'celular_1' => '5512345678',
            'estatus'   => 'aceptada',
        ]);

        $folio = 'CITA-' . str_pad((string) $cita->id, 6, '0', STR_PAD_LEFT);

        $this->postJson('/api/v1/seguimiento', [
            'folio'   => $folio,
            'celular' => '5512345678',
        ])
            ->assertOk()
            ->assertJsonPath('datos.estatus', 'aceptada');
    }

    public function test_el_seguimiento_no_entrega_datos_personales(): void
    {
        $cita = Cita::factory()->create([
            'celular_1' => '5512345678',
            'nombre'    => 'Juan',
            'correo'    => 'juan@ejemplo.com',
            'calle'     => 'Avenida Secreta',
        ]);

        $folio = 'CITA-' . str_pad((string) $cita->id, 6, '0', STR_PAD_LEFT);

        $respuesta = $this->postJson('/api/v1/seguimiento', [
            'folio'   => $folio,
            'celular' => '5512345678',
        ])->assertOk();

        // Ni nombre, ni correo, ni domicilio deben aparecer en la respuesta.
        $cuerpo = $respuesta->getContent();
        $this->assertStringNotContainsString('Juan', $cuerpo);
        $this->assertStringNotContainsString('juan@ejemplo.com', $cuerpo);
        $this->assertStringNotContainsString('Avenida Secreta', $cuerpo);
    }

    public function test_el_seguimiento_rechaza_un_celular_que_no_corresponde(): void
    {
        $cita = Cita::factory()->create(['celular_1' => '5512345678']);
        $folio = 'CITA-' . str_pad((string) $cita->id, 6, '0', STR_PAD_LEFT);

        $this->postJson('/api/v1/seguimiento', [
            'folio'   => $folio,
            'celular' => '5599999999',
        ])->assertNotFound();
    }

    public function test_el_seguimiento_responde_igual_ante_folio_inexistente_y_celular_erroneo(): void
    {
        $cita = Cita::factory()->create(['celular_1' => '5512345678']);
        $folio = 'CITA-' . str_pad((string) $cita->id, 6, '0', STR_PAD_LEFT);

        // Folio real, celular equivocado
        $celularMal = $this->postJson('/api/v1/seguimiento', [
            'folio'   => $folio,
            'celular' => '5599999999',
        ]);

        // Folio que no existe
        $folioMal = $this->postJson('/api/v1/seguimiento', [
            'folio'   => 'CITA-999999',
            'celular' => '5512345678',
        ]);

        // Mismo código y mismo mensaje: no se puede deducir cuál falló.
        $this->assertSame($celularMal->status(), $folioMal->status());
        $this->assertSame(
            $celularMal->json('mensaje'),
            $folioMal->json('mensaje')
        );
    }

    public function test_el_seguimiento_valida_el_formato_del_folio(): void
    {
        $this->postJson('/api/v1/seguimiento', [
            'folio'   => 'INVENTADO-1',
            'celular' => '5512345678',
        ])->assertStatus(422);
    }

    /* ==========================================================
       CHATBOT
    ========================================================== */

    public function test_el_chatbot_responde_a_un_saludo(): void
    {
        $this->postJson(route('chatbot.mensaje'), ['mensaje' => 'hola'])
            ->assertOk()
            ->assertJsonStructure(['ok', 'respuesta', 'sugerencias']);
    }

    public function test_el_chatbot_rechaza_un_mensaje_vacio(): void
    {
        $this->postJson(route('chatbot.mensaje'), ['mensaje' => ''])
            ->assertStatus(422);
    }

    public function test_el_chatbot_pide_el_celular_despues_del_folio(): void
    {
        $respuesta = $this->postJson(route('chatbot.mensaje'), [
            'mensaje' => 'quiero consultar el folio CITA-000014',
        ])->assertOk();

        $this->assertStringContainsString('celular', mb_strtolower($respuesta->json('respuesta')));
    }
}

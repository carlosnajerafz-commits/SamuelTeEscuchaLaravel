<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\V1\ApoyoController;
use App\Http\Controllers\Api\V1\CitaController;
use App\Http\Controllers\Api\V1\CodigoPostalController;
use App\Http\Controllers\Api\V1\ComedorController;
use App\Http\Controllers\Api\V1\EstadisticaController;
use App\Http\Controllers\Api\V1\QuejaController;
use App\Http\Controllers\Api\V1\SeguimientoController;
use App\Http\Controllers\Api\V1\TokenController;

/*
|--------------------------------------------------------------------------
| API v1 — Samuel Te Escucha
|--------------------------------------------------------------------------
|
| Todas las rutas quedan bajo el prefijo /api/v1 y devuelven JSON.
|
| Dos niveles de acceso:
|
|   PÚBLICO      Información que ya es pública en el sitio (catálogo de
|                apoyos, eventos del comedor, códigos postales) y la
|                consulta de seguimiento, que exige folio + celular.
|
|   AUTENTICADO  Todo lo que expone datos personales de los ciudadanos.
|                Requiere un token Bearer emitido a un empleado mediante
|                Laravel Sanctum.
|
*/

Route::prefix('v1')->name('api.v1.')->group(function () {

    /* ============================================================
       PÚBLICO
    ============================================================ */

    // Emisión de token: el empleado entrega usuario y contraseña
    // y recibe un token Bearer. Limitado a 5 intentos por minuto.
    Route::post('token', [TokenController::class, 'store'])
        ->middleware('throttle:5,1')
        ->name('token.store');

    // Catálogo de apoyos activos (sin datos personales)
    Route::get('apoyos', [ApoyoController::class, 'index'])
        ->middleware('throttle:60,1')
        ->name('apoyos.index');

    // Próximos eventos del comedor solidario con su cupo disponible
    Route::get('comedor/eventos', [ComedorController::class, 'index'])
        ->middleware('throttle:60,1')
        ->name('comedor.index');

    // Colonias y municipio de un código postal
    Route::get('codigos-postales/{cp}', [CodigoPostalController::class, 'show'])
        ->where('cp', '[0-9]{5}')
        ->middleware('throttle:60,1')
        ->name('cp.show');

    // Horarios disponibles de un martes concreto
    Route::get('citas/disponibilidad/{fecha}', [CitaController::class, 'disponibilidad'])
        ->where('fecha', '[0-9]{4}-[0-9]{2}-[0-9]{2}')
        ->middleware('throttle:60,1')
        ->name('citas.disponibilidad');

    // Seguimiento ciudadano: exige folio Y celular registrado.
    // Devuelve únicamente el estatus, nunca datos personales.
    Route::post('seguimiento', [SeguimientoController::class, 'consultar'])
        ->middleware('throttle:10,1')
        ->name('seguimiento');

    /* ============================================================
       AUTENTICADO (token Bearer de empleado)
    ============================================================ */

    Route::middleware(['auth:sanctum', 'throttle:120,1'])->group(function () {

        Route::get('me', [TokenController::class, 'me'])->name('me');
        Route::delete('token', [TokenController::class, 'destroy'])->name('token.destroy');

        // Citas
        Route::get('citas', [CitaController::class, 'index'])->name('citas.index');
        Route::get('citas/{cita}', [CitaController::class, 'show'])->name('citas.show');
        Route::patch('citas/{cita}/estatus', [CitaController::class, 'actualizarEstatus'])
            ->name('citas.estatus');

        // Quejas
        Route::get('quejas', [QuejaController::class, 'index'])->name('quejas.index');
        Route::get('quejas/{queja}', [QuejaController::class, 'show'])->name('quejas.show');
        Route::patch('quejas/{queja}/estatus', [QuejaController::class, 'actualizarEstatus'])
            ->name('quejas.estatus');

        // Solicitudes de apoyo
        Route::get('registros-apoyo', [ApoyoController::class, 'registros'])
            ->name('apoyos.registros');
        Route::patch('registros-apoyo/{registro}/estatus', [ApoyoController::class, 'actualizarEstatus'])
            ->name('apoyos.estatus');

        // Registros del comedor
        Route::get('comedor/registros', [ComedorController::class, 'registros'])
            ->name('comedor.registros');

        // Indicadores para tableros externos
        Route::get('estadisticas', [EstadisticaController::class, 'index'])
            ->name('estadisticas');
    });
});

/* ============================================================
   404 en formato JSON para cualquier ruta /api inexistente
============================================================ */
Route::fallback(function () {
    return response()->json([
        'ok'      => false,
        'mensaje' => 'El recurso solicitado no existe.',
    ], 404);
});
